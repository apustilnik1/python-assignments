#Alyssa Pustilnik
#abp2173
#2048 hw 3

import random
from BaseAI import BaseAI
import time
import numpy as np

class IntelligentAgent(BaseAI):
    def getMove(self, grid):
        # Selects a random move and returns it
        #moveset = grid.getAvailableMoves()
        #return random.choice(moveset)[0] if moveset else None
        self.start_time = 0
        return self.decision(grid)
        #0 up
        #1 down
        #2 left

    def minimize(self, state, a, b, d): # Computer
        min_pos, min_utility = None, float('inf')
        for pos in state.getAvailableCells():
            child_2 = state.clone()
            child_2.insertTile(pos=pos, value=2)
            child_4 = state.clone()
            child_4.insertTile(pos=pos, value=4)
            foo, utility_2 = self.maximize(child_2, a, b, d+1)
            foo, utility_4 = self.maximize(child_4, a, b, d+1)
            utility = 0.9 * utility_2 + 0.1 * utility_4

            if utility < min_utility:
                min_pos, min_utility = pos, utility
            if min_utility <= a:
                break
            if min_utility < b:
                b = min_utility

        return min_pos, min_utility

    def maximize(self, state, a, b, d): # Player
        if d >2:
            return (None, eval(state))
        max_move, max_utility = None, float('-inf')
        for move, child in state.getAvailableMoves():
            foo, utility = self.minimize(child, a, b, d+1)

            if utility > max_utility:
                max_move, max_utility = move, utility
            if max_utility >= b:
                break
            if max_utility > a:
                a = max_utility
        return max_move, max_utility
    
    def decision(self, state):
        start_time=time.time()
        ret = self.maximize(state, float('-inf'), float('inf'), 0)[0]
        return ret

def eval(state):
    features = []
    
    num_empty_cells = len(state.getAvailableCells())
    features.append(num_empty_cells)
    
    max_tile = state.getMaxTile()
    features.append(np.log(max_tile))
    
    max_tile_br_corner = state.map[3][3] == max_tile
    features.append(max_tile_br_corner)
    
    w = [[0, 2, 10, 20],
         [0, 3, 10, 30],
         [0, 4, 20, 45],
         [0, 10, 45, 500]]
    weighted_tiles = np.sum(np.multiply(w, state.map))
    features.append(weighted_tiles)

    feature_weights = [15, 5, 750, 7]
    heuristic_score = np.dot(features, feature_weights)

    return heuristic_score 

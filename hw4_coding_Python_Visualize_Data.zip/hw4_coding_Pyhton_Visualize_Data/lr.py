#Alyssa Pustilnik
#abp2173
#hw4
import numpy as np
import pandas as pd
import sys
import plot_db

def main():
    """
    YOUR CODE GOES HERE
    Implement Linear Regression using Gradient Descent, with varying alpha values and numbers of iterations.
    Write to an output csv file the outcome betas for each (alpha, iteration #) setting.
    Please run the file as follows: python3 lr.py data2.csv, results2.csv
    """

    inputf, outcome = sys.argv[1:]
    values = pd.read_csv(inputf, header=None, names=['age', 'weight', 'height'])

    #get 9 values plus 1 of my own values
    alphas = [0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1, 5, 10]
    myalpha = 0.75
    itervals = 100
    myitervals = 50

    mylist =[[myalpha, myitervals]] + [[alpha, itervals] for alpha in alphas]
    output = open(outcome, "w")

    #ages 
    mage= values['age'].mean()
    ageSTD = values['age'].std()
    scage = [( age - mage )/ ageSTD for age in values['age']]

    #weights
    mweight =values['weight'].mean()
    weightSTD = values['weight'].std()
    scweight = [(weight - mweight)/ weightSTD for weight in values['weight']]


    #make sure proper commandline inputs
    if len(sys.argv) != 3:
        raise RuntimeError('Please enter two different files!')

    r = len(values.index)
    values.insert(0, 'Inter', [1 for i in range(r)])

    values['age'] = scage
    values['weight'] = scweight

    #mylist = [ [alpha, itervals] for alpha in alphas ] + [ [myalpha, myitervals] ]
    for alpha, iterations in mylist:
        b = [0 for i in range(3)]
        for i in range(iterations):
            #need intercept, age, weight
            for j, val in enumerate(['Inter', 'age', 'weight']):
                prediction(values, b)
                values[val+'-x'] = values['left'] * values[val]

                sum = values[val+'-x'].sum()
                b[j] -= alpha / r * sum

        # for proper outcomes on the csv
        #print("{0:.3f}".format(a)) for three decimal points
        #made it round to 5 decimal points
        rounded = [ 0 for i in range(3) ]
        rounded[0] = round(b[0] - (mage * b[1] / ageSTD) - (mweight * b[2] / weightSTD ),5)
        rounded[1] = round(b[1] / ageSTD, 5)
        rounded[2] = round(b[2] / weightSTD,5)


        #empty string
        show_data = ''

        show = [str(alpha), str(iterations)] + [str(b) for b in rounded]
        for d in show:
            show_data = show_data+ d + ', '
        show_data = show_data[:-2]

        #remember to close output
        output.write(show_data+'\n')

    output.close()

def prediction(values, b):
    values['prediction'] = np.dot(values[['Inter', 'age', 'weight']], b)
    values['left'] = values['prediction'] - values['height']

if __name__ == "__main__":
    main()

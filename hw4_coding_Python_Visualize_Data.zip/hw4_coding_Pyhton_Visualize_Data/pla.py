#Alyssa Pustilnik
#abp2173
#hw4
import pandas as pd
import numpy as np
import sys
import plot_db

def main():

    #initialize weights step 2
    weights = [0 for i in range(3)]
    converge = False
    #output.write('0'+', '+'0+'', '+'0')

    
    #make sure proper commandline inputs
    if len(sys.argv) != 3:
        raise RuntimeError('Please enter two different files!')

    guess = lambda val1, val2: val1[0] * val2[0] + val2[1] * val1[1] + val2[2]
    input_data, outcome = sys.argv[1:]
    output = open(outcome, "w")
    inputf = pd.read_csv(input_data, header=None)


    #repeat until convergence step 3
    while not converge:
        converge = True
        for row in inputf.iterrows(): #step 4
            values = row[1]
            #step 5
            if 0 >=values[2] * guess(values[:2], weights):
                converge = False
                #adjust the weights step 6
                weights[0] = values[0] * values[2]+ weights[0]
                weights[1] = values[1] * values[2]+ weights[1]
                weights[2] = values[2]+ weights[2]
        #dont forget close output
        #order the output correctly
        output.write(str(weights[0])+', '+str(weights[1])+', '+str(weights[2])+'\n')
    plot_db.visualize_scatter(inputf, weights=weights)
    output.close()

if __name__ == "__main__":
    """DO NOT MODIFY"""
    main()
